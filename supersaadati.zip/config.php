<?php
$db_host = 'localhost';
$db_name = 'databasesuper';
$db_user = 'root';
$db_pass = 'L/fF2>vh7K)Mcy3DXu@`$4';
?>