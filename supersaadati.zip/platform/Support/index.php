<html>
    <script>location.href = "tel:+989919740082"</script>
</html>